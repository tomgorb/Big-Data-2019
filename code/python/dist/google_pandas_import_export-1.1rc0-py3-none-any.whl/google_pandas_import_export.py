# coding=utf-8
import os
import logging
import time
import pandas
from argparse import Namespace
from copy import deepcopy
from datetime import datetime
from random import randint
from google.cloud import bigquery, storage
from google.cloud.exceptions import NotFound

not_propagating_logger = logging.getLogger(name='google_pandas_import_export')
not_propagating_logger.setLevel(level=logging.DEBUG)
not_propagating_logger.propagate = False
ch = logging.StreamHandler()
ch.setLevel(level=logging.DEBUG)
formatter = logging.Formatter(fmt='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(fmt=formatter)
not_propagating_logger.addHandler(hdlr=ch)


def wait_for_job(job):
    while True:
        job.reload()
        if job.state == 'DONE':
            if job.error_result:
                raise RuntimeError(job.errors)
            return True
        time.sleep(1)


def wait_for_jobs(jobs):
    for job in jobs:
        wait_for_job(job)


def table_exists(client, table_reference):
    try:
        client.get_table(table_ref=table_reference)
        return True
    except NotFound:
        return False


def timestamp_randint_string(prefix=None):
    if prefix is None:
        prefix = ''
    return prefix + datetime.now().strftime('%Y%m%d%H%M%S_%f') + '_rand' + str(randint(0, 10**4))


def bq_schema_inferred_from_dataframe(dataframe, timestamp_cols=None, date_cols=None):
    if len(dataframe.columns) == 0:
        raise ValueError('A bq_schema cannot be inferred from a dataframe with no columns')
    if timestamp_cols is None:
        timestamp_cols = []
    if date_cols is None:
        date_cols = []
    bq_schema = []
    for col in dataframe.columns:
        dtype = dataframe[col].dtype
        if col in timestamp_cols:
            bq_schema.append(bigquery.SchemaField(name=col, field_type='TIMESTAMP'))
        elif col in date_cols:
            bq_schema.append(bigquery.SchemaField(name=col, field_type='DATE'))
        elif dtype == float:
            bq_schema.append(bigquery.SchemaField(name=col, field_type='FLOAT'))
        elif dtype == int:
            bq_schema.append(bigquery.SchemaField(name=col, field_type='INTEGER'))
        elif dtype == bool:
            bq_schema.append(bigquery.SchemaField(name=col, field_type='BOOLEAN'))
        else:
            bq_schema.append(bigquery.SchemaField(name=col, field_type='STRING'))
    return bq_schema


locations = ['query', 'bq', 'gs', 'local', 'dataframe']
middle_locations = locations[1: -1]
rlocations = list(reversed(locations))
atomic_function_names = ['query_to_bq', 'bq_to_gs', 'gs_to_local', 'local_to_dataframe',
                         'dataframe_to_local', 'local_to_gs', 'gs_to_bq', 'bq_to_query']


def _build_atomic_function_names(locations1):
    res = []
    for i in range(len(locations1) - 1):
        res.append(locations1[i] + '_to_' + locations1[i + 1])
    return res


def gpie_job_config(
        source,
        destination,

        data_name=None,
        query=None,
        dataframe=None,

        write_disposition='WRITE_TRUNCATE',
        dtype=None,
        infer_datetime_format=True,
        parse_dates=None,
        timestamp_cols=None,
        date_cols=None,
        bq_schema=None,

        delete_in_bq=True,
        delete_in_gs=True,
        delete_in_local=True):
    if source not in locations:
        raise ValueError("source must be one of 'query' or 'bq' or 'gs' or 'local' or 'dataframe'")

    if destination not in locations:
        raise ValueError("destination must be one of 'query' or 'bq' or 'gs' or 'local' or 'dataframe'")

    if source == destination:
        raise ValueError('source must be different from destination')

    if source == 'query' and query is None:
        raise ValueError("query must be given if source == 'query'")

    if source == 'dataframe' and dataframe is None:
        raise ValueError("dataframe must be given if source == 'dataframe'")

    if source != 'query' and query is not None:
        raise ValueError("query is useless if source != 'query'")

    if source != 'dataframe' and dataframe is not None:
        raise ValueError("dataframe is useless if source != 'dataframe'")

    if data_name is None and (source in middle_locations or destination in middle_locations):
        raise ValueError("data_name must be given if source or destination is one of 'bq' or 'gs' or 'local'")

    if source in ('local', 'gs') and destination in ('bq', 'query') and bq_schema is None:
        raise ValueError('bq_schema is missing')

    return Namespace(
        source=source,
        destination=destination,

        data_name=data_name,
        query=query,
        dataframe=dataframe,

        write_disposition=write_disposition,
        dtype=dtype,
        infer_datetime_format=infer_datetime_format,
        parse_dates=parse_dates,
        timestamp_cols=timestamp_cols,
        date_cols=date_cols,
        bq_schema=bq_schema,

        delete_in_bq=delete_in_bq,
        delete_in_gs=delete_in_gs,
        delete_in_local=delete_in_local)


class GooglePandasImportExport(object):

    def __init__(self,
                 bq_client=None,
                 dataset_ref=None,
                 bucket=None,
                 gs_dir_path_in_bucket=None,
                 local_dir_path=None,
                 generated_data_name_prefix=None,
                 max_concurrent_google_jobs=10,
                 use_wildcard=True,
                 compress=True,
                 separator='|',
                 chunk_size=2**28,
                 logger=not_propagating_logger,
                 log_level=10,
                 return_monitoring_report=False):
        self._bq_client = bq_client
        self._dataset_ref = dataset_ref
        self._bucket = bucket
        self._gs_dir_path_in_bucket = gs_dir_path_in_bucket
        if self._bucket is not None:
            if self._gs_dir_path_in_bucket is None:
                self._gs_dir_uri = os.path.join('gs://', self._bucket.name)
            else:
                self._gs_dir_uri = os.path.join('gs://', self._bucket.name, self._gs_dir_path_in_bucket)
        self._local_dir_path = local_dir_path
        self._generated_data_name_prefix = generated_data_name_prefix

        self._mcgj = max_concurrent_google_jobs

        self._use_wildcard = use_wildcard
        if self._use_wildcard:
            self._bq_to_gs_ext = '-*.csv'
        else:
            self._bq_to_gs_ext = '.csv'
        self._dataframe_to_local_ext = '.csv'
        self._compress = compress
        if self._compress:
            self._bq_to_gs_ext += '.gz'
            self._bq_to_gs_compression = 'GZIP'
            self._dataframe_to_local_ext += '.gz'
            self._dataframe_to_local_compression = 'gzip'
        else:
            self._bq_to_gs_compression = None
            self._dataframe_to_local_compression = None

        self._separator = separator
        self._chunk_size = chunk_size
        self._logger = logger
        self._log_level = log_level
        self._return_monitoring_report = return_monitoring_report
        self._atomic_functions = [self._query_to_bq, self._bq_to_gs, self._gs_to_local, self._local_to_dataframe,
                                  self._dataframe_to_local, self._local_to_gs, self._gs_to_bq, self._bq_to_query]

    def blob_list(self, data_name):
        if self._gs_dir_path_in_bucket is None:
            prefix = data_name
        else:
            prefix = os.path.join(self._gs_dir_path_in_bucket, data_name)
        return list(self._bucket.list_blobs(prefix=prefix))

    def blob_uri_list(self, data_name):
        return [os.path.join(self._gs_dir_uri, os.path.basename(blob.name))
                for blob in self.blob_list(data_name=data_name)]

    def local_file_path_list(self, data_name):
        return [os.path.join(self._local_dir_path, basename)
                for basename in os.listdir(self._local_dir_path)
                if basename.startswith(data_name)]

    def exist_in_bq(self, data_name):
        table_ref = self._dataset_ref.table(table_id=data_name)
        return table_exists(client=self._bq_client, table_reference=table_ref)

    def exist_in_gs(self, data_name):
        return len(self.blob_list(data_name=data_name)) > 0

    def exist_in_local(self, data_name):
        return len(self.local_file_path_list(data_name=data_name)) > 0

    def delete_in_bq(self, data_name, warn=True):
        if self.exist_in_bq(data_name=data_name):
            table_ref = self._dataset_ref.table(table_id=data_name)
            self._bq_client.delete_table(table=table_ref)
        elif warn:
            self._logger.warning('There is no data named {} in bq'.format(data_name))

    def delete_in_gs(self, data_name, warn=True):
        if self.exist_in_gs(data_name=data_name):
            self._bucket.delete_blobs(blobs=self.blob_list(data_name=data_name))
        elif warn:
            self._logger.warning('There is no data named {} in gs'.format(data_name))

    def delete_in_local(self, data_name, warn=True):
        if self.exist_in_local(data_name=data_name):
            for local_file_path in self.local_file_path_list(data_name=data_name):
                os.remove(local_file_path)
        elif warn:
            self._logger.warning('There is no data named {} in local'.format(data_name))

    def _query_to_bq(self, configs):
        self._logger.log(self._log_level, 'Starting query to bq...')
        start_timestamp = datetime.now()
        total_bytes_billed_list = []
        nb_of_batches = len(configs)//self._mcgj + 1
        for i in range(nb_of_batches):
            jobs = []
            for config in configs[i*self._mcgj:(i+1)*self._mcgj]:
                job_config = bigquery.job.QueryJobConfig()
                job_config.destination = self._dataset_ref.table(table_id=config.data_name)
                job_config.write_disposition = config.write_disposition
                job = self._bq_client.query(query=config.query,
                                            job_config=job_config)
                jobs.append(job)
            wait_for_jobs(jobs=jobs)
            total_bytes_billed_list += [j.total_bytes_billed for j in jobs]
        costs = [round(tbb/2**40*5, 5) for tbb in total_bytes_billed_list]
        cost = sum(costs)
        end_timestamp = datetime.now()
        duration = (end_timestamp - start_timestamp).seconds
        self._logger.log(self._log_level, 'Ended query to bq [{}s, {}$]'.format(duration, cost))
        return duration, cost, costs

    def _bq_to_gs(self, configs):
        self._logger.log(self._log_level, 'Starting bq to gs...')
        start_timestamp = datetime.now()
        for config in configs:
            self.delete_in_gs(data_name=config.data_name, warn=False)
        nb_of_batches = len(configs)//self._mcgj + 1
        for i in range(nb_of_batches):
            jobs = []
            for config in configs[i*self._mcgj:(i+1)*self._mcgj]:
                if not self.exist_in_bq(data_name=config.data_name):
                    raise ValueError('There is no data named {} in bq'.format(config.data_name))
                source = self._dataset_ref.table(table_id=config.data_name)
                job_config = bigquery.job.ExtractJobConfig()
                job_config.compression = self._bq_to_gs_compression
                destination_uri = os.path.join(self._gs_dir_uri, config.data_name + self._bq_to_gs_ext)
                job_config.field_delimiter = self._separator
                job = self._bq_client.extract_table(source=source,
                                                    destination_uris=destination_uri,
                                                    job_config=job_config)
                jobs.append(job)
            wait_for_jobs(jobs=jobs)
        for config in configs:
            if config.delete_in_source:
                self.delete_in_bq(data_name=config.data_name)
        end_timestamp = datetime.now()
        duration = (end_timestamp - start_timestamp).seconds
        self._logger.log(self._log_level, 'Ended bq to gs [{}s]'.format(duration))
        return duration

    def _gs_to_local(self, configs):
        self._logger.log(self._log_level, 'Starting gs to local...')
        start_timestamp = datetime.now()
        for config in configs:
            self.delete_in_local(data_name=config.data_name, warn=False)
        for config in configs:
            if not self.exist_in_gs(data_name=config.data_name):
                raise ValueError('There is no data named {} in gs'.format(config.data_name))
            for blob in self.blob_list(data_name=config.data_name):
                blob.download_to_filename(filename=os.path.join(self._local_dir_path, os.path.basename(blob.name)))
        for config in configs:
            if config.delete_in_source:
                self.delete_in_gs(data_name=config.data_name)
        end_timestamp = datetime.now()
        duration = (end_timestamp - start_timestamp).seconds
        self._logger.log(self._log_level, 'Ended gs to local [{}s]'.format(duration))
        return duration

    def _local_to_dataframe(self, configs):
        self._logger.log(self._log_level, 'Starting local to dataframe...')
        start_timestamp = datetime.now()
        dataframe_list = []
        for config in configs:
            if not self.exist_in_local(data_name=config.data_name):
                raise ValueError('There is no data named {} in local'.format(config.data_name))
            dataframe_bits = []
            for local_file_path in self.local_file_path_list(data_name=config.data_name):
                dataframe_bit = pandas.read_csv(filepath_or_buffer=local_file_path,
                                                sep=self._separator,
                                                dtype=config.dtype,
                                                parse_dates=config.parse_dates,
                                                infer_datetime_format=config.infer_datetime_format)
                dataframe_bits.append(dataframe_bit)
            dataframe = pandas.concat(dataframe_bits)
            dataframe_list.append(dataframe)
        for config in configs:
            if config.delete_in_source:
                self.delete_in_local(data_name=config.data_name)
        end_timestamp = datetime.now()
        duration = (end_timestamp - start_timestamp).seconds
        self._logger.log(self._log_level, 'Ended local to dataframe [{}s]'.format(duration))
        return duration, dataframe_list

    def _dataframe_to_local(self, configs):
        self._logger.log(self._log_level, 'Starting dataframe to local...')
        start_timestamp = datetime.now()
        for config in configs:
            self.delete_in_local(data_name=config.data_name, warn=False)
        for config in configs:
            config.dataframe.to_csv(path_or_buf=os.path.join(self._local_dir_path,
                                                             config.data_name + self._dataframe_to_local_ext),
                                    sep=self._separator,
                                    index=False,
                                    compression=self._dataframe_to_local_compression)
        end_timestamp = datetime.now()
        duration = (end_timestamp - start_timestamp).seconds
        self._logger.log(self._log_level, 'Ended dataframe to local [{}s]'.format(duration))
        return duration

    def _local_to_gs(self, configs):
        self._logger.log(self._log_level, 'Starting local to gs...')
        start_timestamp = datetime.now()
        for config in configs:
            self.delete_in_gs(data_name=config.data_name, warn=False)
        for config in configs:
            if not self.exist_in_local(data_name=config.data_name):
                raise ValueError('There is no data named {} in local'.format(config.data_name))
            for local_file_path in self.local_file_path_list(data_name=config.data_name):
                basename = os.path.basename(local_file_path)
                if self._gs_dir_path_in_bucket is None:
                    name = basename
                else:
                    name = os.path.join(self._gs_dir_path_in_bucket, basename)
                blob = storage.Blob(name=name,
                                    bucket=self._bucket,
                                    chunk_size=self._chunk_size)
                blob.upload_from_filename(filename=local_file_path)
        for config in configs:
            if config.delete_in_source:
                self.delete_in_local(data_name=config.data_name)
        end_timestamp = datetime.now()
        duration = (end_timestamp - start_timestamp).seconds
        self._logger.log(self._log_level, 'Ended local to gs [{}s]'.format(duration))
        return duration

    def _gs_to_bq(self, configs):
        self._logger.log(self._log_level, 'Starting gs to bq...')
        start_timestamp = datetime.now()
        nb_of_batches = len(configs)//self._mcgj + 1
        for i in range(nb_of_batches):
            jobs = []
            for config in configs[i*self._mcgj:(i+1)*self._mcgj]:
                if not self.exist_in_gs(data_name=config.data_name):
                    raise ValueError('There is no data named {} in gs'.format(config.data_name))
                job_config = bigquery.job.LoadJobConfig()
                job_config.field_delimiter = self._separator
                job_config.schema = config.schema
                job_config.skip_leading_rows = 1
                job_config.write_disposition = config.write_disposition
                job = self._bq_client.load_table_from_uri(
                    source_uris=self.blob_uri_list(data_name=config.data_name),
                    destination=self._dataset_ref.table(table_id=config.data_name),
                    job_config=job_config)
                jobs.append(job)
            wait_for_jobs(jobs=jobs)
        for config in configs:
            if config.delete_in_source:
                self.delete_in_gs(data_name=config.data_name)
        end_timestamp = datetime.now()
        duration = (end_timestamp - start_timestamp).seconds
        self._logger.log(self._log_level, 'Ended gs to bq [{}s]'.format(duration))
        return duration

    def _bq_to_query(self, configs):
        self._logger.log(self._log_level, 'Starting bq to query...')
        start_timestamp = datetime.now()
        query_list = []
        for config in configs:
            if not self.exist_in_bq(data_name=config.data_name):
                raise ValueError('There is no data named {} in bq'.format(config.data_name))
            query_list.append('select * from `{}.{}.{}`'.format(self._dataset_ref.project,
                                                                self._dataset_ref.dataset_id,
                                                                config.data_name))
        end_timestamp = datetime.now()
        duration = (end_timestamp - start_timestamp).seconds
        self._logger.log(self._log_level, 'Ended bq to query [{}s]'.format(duration))
        return duration, query_list

    def _return_monitoring_report_submit(self, job_configs):
        le = len(job_configs)

        job_configs = [deepcopy(job_config) for job_config in job_configs]

        for job_config in job_configs:
            if job_config.data_name is None:
                job_config.data_name = timestamp_randint_string(prefix=self._generated_data_name_prefix)

        data_names = [job_config.data_name for job_config in job_configs]
        for i, dn1 in enumerate(data_names):
            for j, dn2 in enumerate(data_names):
                if i != j and dn2.startswith(dn1):
                    raise ValueError('{} is a prefix of {}'.format(dn1, dn2))

        for job_config in job_configs:
            if job_config.dataframe is not None and job_config.bq_schema is None:
                job_config.bq_schema = bq_schema_inferred_from_dataframe(dataframe=job_config.dataframe,
                                                                         timestamp_cols=job_config.timestamp_cols,
                                                                         date_cols=job_config.date_cols)

        # dc = detailed_config
        dcs = []
        for job_config in job_configs:
            dc = dict()
            dc['query_to_bq'] = Namespace(
                data_name=job_config.data_name,
                query=job_config.query,
                write_disposition=job_config.write_disposition)
            dc['bq_to_gs'] = Namespace(
                data_name=job_config.data_name,
                delete_in_source=job_config.delete_in_bq)
            dc['gs_to_local'] = Namespace(
                data_name=job_config.data_name,
                delete_in_source=job_config.delete_in_gs)
            dc['local_to_dataframe'] = Namespace(
                data_name=job_config.data_name,
                dtype=job_config.dtype,
                parse_dates=job_config.parse_dates,
                infer_datetime_format=job_config.infer_datetime_format,
                delete_in_source=job_config.delete_in_local)

            dc['dataframe_to_local'] = Namespace(
                data_name=job_config.data_name,
                dataframe=job_config.dataframe)
            dc['local_to_gs'] = Namespace(
                data_name=job_config.data_name,
                delete_in_source=job_config.delete_in_local)
            dc['gs_to_bq'] = Namespace(
                data_name=job_config.data_name,
                schema=job_config.bq_schema,
                write_disposition=job_config.write_disposition,
                delete_in_source=job_config.delete_in_gs)
            dc['bq_to_query'] = Namespace(
                data_name=job_config.data_name)

            index_source = locations.index(job_config.source)
            index_destination = locations.index(job_config.destination)
            rindex_source = rlocations.index(job_config.source)
            rindex_destination = rlocations.index(job_config.destination)

            if index_source < index_destination:
                to_call = _build_atomic_function_names(locations[index_source: index_destination + 1])
            else:
                to_call = _build_atomic_function_names(rlocations[rindex_source: rindex_destination + 1])

            for n in atomic_function_names:
                if n not in to_call:
                    del dc[n]

            dcs.append(dc)

        to_call = [n for n in atomic_function_names if any(n in dc for dc in dcs)]

        if self._bq_client is None and any('bq' in n for n in to_call):
            raise ValueError('bq_client must be given if bq is used')

        if self._dataset_ref is None and any('bq' in n for n in to_call):
            raise ValueError('dataset_ref must be given if bq is used')

        if self._bucket is None and any('gs' in n for n in to_call):
            raise ValueError('bucket must be given if gs is used')

        if self._local_dir_path is None and any('local' in n for n in to_call):
            raise ValueError('local_dir_path must be given if local is used')

        outputs = dict()
        duration = 0
        durations = dict()
        query_cost = None
        query_costs = dict()
        for n, f in zip(atomic_function_names, self._atomic_functions):
            f_indices = []
            f_configs = []
            for i, s in enumerate(dcs):
                if n in s:
                    f_indices.append(i)
                    f_configs.append(s[n])
            if f_configs:
                res = f(configs=f_configs)
                if n == 'query_to_bq':
                    f_duration, f_cost, f_costs = res
                    query_cost = f_cost
                    for i in f_indices:
                        query_costs[i] = f_costs.pop(0)
                elif n in ('local_to_dataframe', 'bq_to_query'):
                    f_duration, f_outputs = res
                    for i in f_indices:
                        outputs[i] = f_outputs.pop(0)
                else:
                    f_duration = res
                durations[n] = f_duration
                duration += f_duration

        outputs = [outputs.get(i) for i in range(le)]

        query_costs = [query_costs.get(i) for i in range(le)]
        monitoring_report = {'data_names': data_names,
                             'durations': durations,
                             'duration': duration,
                             'query_costs': query_costs,
                             'query_cost': query_cost}

        return outputs, monitoring_report

    def submit(self, job_configs):
        outputs, monitoring_report = self._return_monitoring_report_submit(job_configs=job_configs)

        if self._return_monitoring_report:
            return outputs, monitoring_report
        else:
            return outputs

    def convey(self,
               source,
               destination,

               data_name=None,
               query=None,
               dataframe=None,

               write_disposition='WRITE_TRUNCATE',
               dtype=None,
               infer_datetime_format=True,
               parse_dates=None,
               timestamp_cols=None,
               date_cols=None,
               bq_schema=None,

               delete_in_bq=True,
               delete_in_gs=True,
               delete_in_local=True):
        job_config = gpie_job_config(
            source,
            destination,

            data_name=data_name,
            query=query,
            dataframe=dataframe,

            write_disposition=write_disposition,
            dtype=dtype,
            infer_datetime_format=infer_datetime_format,
            parse_dates=parse_dates,
            timestamp_cols=timestamp_cols,
            date_cols=date_cols,
            bq_schema=bq_schema,

            delete_in_bq=delete_in_bq,
            delete_in_gs=delete_in_gs,
            delete_in_local=delete_in_local)

        outputs, monitoring_report = self._return_monitoring_report_submit(job_configs=[job_config])

        monitoring_report = {'data_name': monitoring_report['data_names'][0],
                             'durations': monitoring_report['durations'],
                             'duration': monitoring_report['duration'],
                             'query_cost': monitoring_report['query_cost']}

        if self._return_monitoring_report:
            return outputs[0], monitoring_report
        else:
            return outputs[0]


class GooglePandasImportExportPoc(GooglePandasImportExport):

    def __init__(self,
                 bq_client=bigquery.Client(project='dmp-y-tests'),
                 dataset_ref=bigquery.dataset.DatasetReference(project='dmp-y-tests', dataset_id='tmp'),
                 bucket=storage.bucket.Bucket(client=storage.Client(project='dmp-y-tests'), name='augustin-b-bucket'),
                 gs_dir_path_in_bucket=None,
                 local_dir_path='/tmp',
                 generated_data_name_prefix=None,
                 max_concurrent_google_jobs=40,
                 use_wildcard=True,
                 compress=True,
                 separator='|',
                 chunk_size=2**28,
                 logger=not_propagating_logger,
                 log_level=10,
                 return_monitoring_report=False):
        super().__init__(bq_client=bq_client,
                         dataset_ref=dataset_ref,
                         bucket=bucket,
                         gs_dir_path_in_bucket=gs_dir_path_in_bucket,
                         local_dir_path=local_dir_path,
                         generated_data_name_prefix=generated_data_name_prefix,
                         max_concurrent_google_jobs=max_concurrent_google_jobs,
                         use_wildcard=use_wildcard,
                         compress=compress,
                         separator=separator,
                         chunk_size=chunk_size,
                         logger=logger,
                         log_level=log_level,
                         return_monitoring_report=return_monitoring_report)


def copy_bq_table_list(bq_client,
                       source_table_ref_list,
                       destination_table_ref_list,
                       write_disposition='WRITE_TRUNCATE',
                       max_concurrent_google_jobs=10,
                       delete_source=False,
                       logger=not_propagating_logger,
                       log_level=10):
    logger.log(log_level, 'Copying bq tables...')
    start_timestamp = datetime.now()
    if len(source_table_ref_list) != len(destination_table_ref_list):
        raise ValueError('source_table_ref_list and destination_table_ref_list must have the same length')
    mcgj = max_concurrent_google_jobs
    nb_of_batches = len(source_table_ref_list)//mcgj + 1
    ll = list(zip(source_table_ref_list, destination_table_ref_list))
    for i in range(nb_of_batches):
        jobs = []
        for source_table_ref, destination_table_ref in ll[i*mcgj: (i+1)*mcgj]:
            job_config = bigquery.job.CopyJobConfig()
            job_config.write_disposition = write_disposition
            job = bq_client.copy_table(sources=source_table_ref,
                                       destination=destination_table_ref,
                                       job_config=job_config)
            jobs.append(job)
        wait_for_jobs(jobs=jobs)
    if delete_source:
        for source_table_ref in source_table_ref_list:
            bq_client.delete_table(table=source_table_ref)
    end_timestamp = datetime.now()
    duration = (end_timestamp - start_timestamp).seconds
    logger.log(log_level, 'Copied bq tables [{}s]'.format(duration))
    return duration
